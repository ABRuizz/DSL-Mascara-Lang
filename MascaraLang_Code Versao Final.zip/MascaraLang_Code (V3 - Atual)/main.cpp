new j1, j2, j3, j4, j5, j6, j7;

j1 habilidade(rei);
j5 contestar(rei, j1);
j2 revelar();
j3 troca(j5);
j4 habilidade(viuva);
j5 blefe_troca(j7);
j6 habilidade(juiz);
j7 habilidade(princesa, j5);
j1 habilidade(pedinte);
j2 habilidade(benfeitor);
j3 contestar(benfeitor, j2);
j3 habilidade(benfeitor);
j4 habilidade(traidor);