from lex import lex
import sys

### Habilidades Personagens ###
# Rei - ganha 2 moedas do banco
# Traidor - ganha se tiver pelo menos 10 moedas
# Juiz - pega todas as moedas do tribunal para si
# Pedinte - em sentido horário, pega uma moeda de um jogador se o jogador tiver mais moedas do que você
# Viuva - ganha moedas do banco até ter um total de 10
# Princesa - ganha 2 moedas do banco e escolhe um jogador da mesa para revelar sua carta
# Benfeitor - ganha 3 moedas do banco e os jogadores a sua direita e esquerda gannham 1 moeda do banco
###############################
# 1° passo: Definindo os tokes
tokens = ("JOGADOR", "ACAO", "PERSONAGEM","FIM_COMANDO", "NOVA_INSTANCIA", "IDENTIFICADOR",
 "SEPARADOR", "ABRE_PARENTESES", "FECHA_PARENTESES")

# 2° passo: Definindo as linguagens regulares de cada token (regex)
t_NOVA_INSTANCIA = "new"
t_JOGADOR = "j\d+" 
t_ACAO = "troca | blefe_troca | revelar | habilidade | contestar"
t_PERSONAGEM = "rei | traidor | juiz | pedinte | viuva | princesa | benfeitor"
t_FIM_COMANDO = "\;"
t_SEPARADOR = "\,"
t_ABRE_PARENTESES = "\("
t_FECHA_PARENTESES = "\)"

#Modificador Jogador , Jogador, Jogador;
#Jogador Acao (Jogador | Personagem | Jogador, Personagem)

def t_MUDA_LINHA(t):
    r"\n"
    t.lexer.lineno += 1

#Esses tokens são pre-definidos e não precisam ser declarados na tupla "tokens"
t_ignore = " "
#Definir como uma função
def t_error(t):
    print(t, "não foi reconhecido!")
    sys.exit(0)

def inicializaLexer(arquivo):
    # 3°passo: Abrir o código fonte
    data = open(arquivo)
    conteudo = data.read()
    print(conteudo)

    # 4°passo: Instanciar o Lexer
    lexer = lex()
    lexer.input(conteudo)
    return lexer