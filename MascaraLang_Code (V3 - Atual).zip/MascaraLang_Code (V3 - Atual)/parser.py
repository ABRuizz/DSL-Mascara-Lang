from lexer import inicializaLexer
import random as rand
import sys

lexer = inicializaLexer("main.cpp")

lookAhead = lexer.token() #Inicializando o lookAhead - sempre olha o próximo token

simbolos = {}

personagensMesa = ["rei", "traidor", "juiz", "pedinte", "princesa", "viuva", "benfeitor"] #personagens que ainda não estão na mão de nenhum jogador

tribunal = 0 #constante que armazena moedas
lineno = " " #utilizada exclusivamente para iformar linha ao identificar erro sintático quando 'lookahead' == None

def print_status():
    print("============================ CURRENT STATUS ===========================")
    for s in simbolos:
        print(simbolos[s])

def verificaExistencia(lexema):
    global simbolos
    return lexema in simbolos

def adicionarVariavel(lexema):
    global simbolos
    global personagensMesa

    if(len(personagensMesa) > 0): 
        index = rand.randint(0, len(personagensMesa)-1)
        personagem = personagensMesa[index]
        personagensMesa.remove(personagem)

        simbolos[lexema]={
            "id": lexema,
            "moedas": 6,
            "personagem": personagem,
            "posicao": len(simbolos)
        }
    else:
        print("Erro: quantidade de jogadores maior do que a quantidade de personagens:", len(simbolos))
        sys.exit()

def analisaVariavel(identificador, linha):
    if verificaExistencia(identificador):
        print("Erro semântico(linha " + str(linha) + "):", identificador,
        "já previamente declarado")
        sys.exit(1)
    else:
        adicionarVariavel(identificador)

def verificaJogadorNaoDeclarado(identificador, linha):
    global simbolos
    if not verificaExistencia(identificador):
        print("Erro semântico(linha " + str(linha) + "):", identificador,
        "já previamente declarado")
        sys.exit(1)
    return simbolos[identificador]

def match(esperado):
    global lookAhead, lineno
    if lookAhead != None and esperado == lookAhead.type:
        lineno = str(lookAhead.lineno)
        lookAhead = lexer.token() #continua o processo
        return

    print("Erro sintático na linha ", lineno, " Esperado ", esperado, " Lido ", lookAhead)
    sys.exit(1)

def previewNextToken():
    memLex = lexer.clone()
    token = memLex.token()
    return token

#todo não terminal vira um método!

def atualizarMoedas(jogador, quantidade):
    global simbolos
    jogador["moedas"] += quantidade
    if jogador["moedas"] >= 13:
        print("jogador", jogador["id"], "possui", str(jogador["moedas"]), "moedas e ganhou o jogo!")
        print_status()
        sys.exit(1)
    print("jogador", jogador["id"], "possui", str(jogador["moedas"]), "moedas")

def trocar(jogador, jogadorAlvo):
    global simbolos
    for s in simbolos:
        print(simbolos[s])
    
    mem = jogador["personagem"]
    jogador["personagem"] = jogadorAlvo["personagem"]
    jogadorAlvo["personagem"] = mem

def revelarCarta(jogador):
    print("jogador", jogador["id"], "esta com o personagem ", jogador["personagem"])

def contestar(jogador, personagem, jogadorAlvo):
    global simbolos
    global tribunal
    print("jogador",jogador["id"],"contestou a habilidade de", personagem, "do jogador",jogadorAlvo["id"])
    revelarCarta(jogador)
    revelarCarta(jogadorAlvo)
    if jogadorAlvo["personagem"] == personagem:
        if jogador["moedas"] > 0:
            atualizarMoedas(jogador, -1)
            tribunal += 1
        else:
            print("jogador", jogador["id"], "ja tem 0 moedas")
        habilidadePersonagem(jogadorAlvo, personagem, jogador)
    elif jogador["personagem"] == personagem:
        if jogadorAlvo["moedas"] > 0:
            atualizarMoedas(jogadorAlvo, -1)
            tribunal += 1
        else:
            print("jogador", jogadorAlvo["id"], "ja tem 0 moedas")
        habilidadePersonagem(jogador, personagem, jogador)
    else:
        if jogador["moedas"] > 0:
            atualizarMoedas(jogador, -1)
            tribunal += 1
        else:
            print("jogador", jogador["id"], "ja tem 0 moedas")
        if jogadorAlvo["moedas"] > 0:
            atualizarMoedas(jogadorAlvo, -1)
            tribunal += 1
        else:
            print("jogador", jogadorAlvo["id"], "ja tem 0 moedas")
    

def habilidadePersonagem(jogador, personagem, jogadorAlvo=None):
    global simbolos
    global tribunal

    tokenFuturo = previewNextToken()
    if tokenFuturo == None:
        pass
    elif tokenFuturo.type == "ACAO" and tokenFuturo.value == "contestar":
        return

    match personagem:
        case "rei":
            print(jogador["id"], " usou a habilidade de ", personagem)
            atualizarMoedas(jogador, 2)
        case "traidor":
            print(jogador["id"], " usou a habilidade de ", personagem)
            if jogador["moedas"] >= 10:
                print("Jogador ", jogador["id"], "possui ", jogador["moedas"], " moedas e ganhou o jogo!")
                print_status()
                sys.exit(1)
        case "juiz":
            print(jogador["id"], " usou a habilidade de ", personagem)
            atualizarMoedas(jogador, tribunal)
            tribunal = 0
        case "pedinte":
            print(jogador["id"], " usou a habilidade de ", personagem)
            for s in simbolos:
                if simbolos[s] != jogador and simbolos[s]["moedas"] > jogador["moedas"]:
                    atualizarMoedas(simbolos[s], -1)
                    atualizarMoedas(jogador,1)
        case "princesa":
            print(jogador["id"], " usou a habilidade de ", personagem)
            atualizarMoedas(jogador, 2)
            revelarCarta(jogadorAlvo)
        case "viuva":
            print(jogador["id"], " usou a habilidade de ", personagem)
            if jogador["moedas"] < 10:
                atualizarMoedas(jogador, 10 - jogador["moedas"])
            else:
                print("jogador", jogador["id"], "ja possui 10 moedas")
        case "benfeitor":
            print(jogador["id"], " usou a habilidade de ", personagem)
            atualizarMoedas(jogador, 3)
            if len(simbolos) == 1: return #validação: existem + de um jogador
            if jogador["posicao"] == 0:
                for s in simbolos:
                    if simbolos[s]["posicao"] == jogador["posicao"] + 1:
                        atualizarMoedas(simbolos[s], 1)
                    elif simbolos[s]["posicao"] == len(simbolos) - 1:
                        atualizarMoedas(simbolos[s], 1)
            elif jogador["posicao"] == len(simbolos) - 1:
                for s in simbolos:
                    if simbolos[s]["posicao"] == 0:
                        atualizarMoedas(simbolos[s], 1)
                    elif simbolos[s]["posicao"] == jogador["posicao"] - 1:
                        atualizarMoedas(simbolos[s], 1)
            else:
                for s in simbolos:
                    if simbolos[s]["posicao"] == jogador["posicao"] + 1:
                        atualizarMoedas(simbolos[s], 1)
                    elif simbolos[s]["posicao"] == jogador["posicao"] - 1:
                        atualizarMoedas(simbolos[s], 1)


    return

def executaAcao(jogador, acao, personagem=None, jogadorAlvo=None):
    match acao:
        case "troca":
            trocar(jogador, jogadorAlvo)
            print("jogador ", jogador["id"], "trocou com ", jogadorAlvo["id"], "?")
        case "blefe_troca":
            print("jogador ", jogador["id"], "trocou com ", jogadorAlvo["id"], "?")
        case "revelar":
            revelarCarta(jogador)
        case "contestar":
            contestar(jogador, personagem, jogadorAlvo)  
        case "habilidade":
            habilidadePersonagem(jogador, personagem, jogadorAlvo)


    return

def expressao(jogador):
    if lookAhead.type == "ACAO":
        personagem = None
        jogadorAlvo = None
        acao = lookAhead.value
        match("ACAO")
        match("ABRE_PARENTESES")
        if lookAhead.type == "PERSONAGEM":
            personagem = lookAhead.value
            match("PERSONAGEM")
            if lookAhead.type == "SEPARADOR":
                match("SEPARADOR")
                identificador = lookAhead.value
                jogadorAlvo = verificaJogadorNaoDeclarado(identificador, lookAhead.lineno)
                match("JOGADOR")
        elif lookAhead.type == "JOGADOR":
            identificador = lookAhead.value
            jogadorAlvo = verificaJogadorNaoDeclarado(identificador, lookAhead.lineno)
            match("JOGADOR")
        match("FECHA_PARENTESES")
        match("FIM_COMANDO")
        executaAcao(jogador, acao, personagem, jogadorAlvo)


def corpoCMD():
    if lookAhead == None:
        return

    elif lookAhead.type == "JOGADOR":
        identificador = lookAhead.value
        jogador = verificaJogadorNaoDeclarado(identificador, lookAhead.lineno)
        match("JOGADOR")
        expressao(jogador)
        corpoCMD()

    else:    
        print("Erro semântico(linha " + str(lookAhead.lineno) + "):", "Esperado JOGADOR Lido",
              lookAhead.type, "'" + lookAhead.value + "'")
        sys.exit(1)
    

def listaVar():
    if lookAhead == None:
        return
    if lookAhead.type == "FIM_COMANDO":
        match("FIM_COMANDO") #valida e chama o próximo token
        declaracao()
    elif lookAhead.type == "SEPARADOR":
        match("SEPARADOR")
        identificador = lookAhead.value #devo buscar as variáveis de interesse antes do match (pq atualiza o token)
        analisaVariavel(identificador, lookAhead.lineno)
        match("JOGADOR")
        listaVar()


def declaracao():
    global lookAhead
    if lookAhead == None:
        return
        
    if lookAhead.type == "NOVA_INSTANCIA":
        match("NOVA_INSTANCIA")
        if lookAhead.type == "JOGADOR":
            identificador = lookAhead.value
            analisaVariavel(identificador, lookAhead.lineno)
            match("JOGADOR")
            listaVar()

def corpo():
    declaracao()
    corpoCMD()

def programa():
    global simbolos
    print("============================ START ===========================")
    corpo()

programa()
print_status()
